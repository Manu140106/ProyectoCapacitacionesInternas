package com.eam.capacitaciones.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReporteDesempenoDTO {
    private UsuarioDTO usuario;
    private Integer cursosInscritos;
    private Integer cursosCompletados;
    private BigDecimal promedioCalificaciones;
    private Integer badgesObtenidos;
    private String departamento;
}