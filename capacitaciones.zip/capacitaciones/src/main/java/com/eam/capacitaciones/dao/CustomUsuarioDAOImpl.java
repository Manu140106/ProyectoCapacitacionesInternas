package com.eam.capacitaciones.dao;

import com.eam.capacitaciones.domain.entity.Usuario;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Repository;

import java.util.*;
import java.util.stream.Collectors;

@Repository
@Slf4j
public class CustomUsuarioDAOImpl implements CustomUsuarioDAO {

    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<Usuario> buscarUsuariosConFiltros(String nombre, String email, 
                                                   String rol, String departamento, Boolean activo) {
        log.debug("Buscando usuarios con filtros: nombre={}, email={}, rol={}, departamento={}, activo={}", 
                  nombre, email, rol, departamento, activo);

        CriteriaBuilder cb = entityManager.getCriteriaBuilder();
        CriteriaQuery<Usuario> cq = cb.createQuery(Usuario.class);
        Root<Usuario> usuario = cq.from(Usuario.class);

        List<Predicate> predicates = new ArrayList<>();

        if (nombre != null && !nombre.isEmpty()) {
            predicates.add(cb.like(cb.lower(usuario.get("nombre")), 
                                   "%" + nombre.toLowerCase() + "%"));
        }

        if (email != null && !email.isEmpty()) {
            predicates.add(cb.like(cb.lower(usuario.get("email")), 
                                   "%" + email.toLowerCase() + "%"));
        }

        if (rol != null && !rol.isEmpty()) {
            predicates.add(cb.equal(usuario.get("rol"), Usuario.RolEnum.valueOf(rol)));
        }

        if (departamento != null && !departamento.isEmpty()) {
            predicates.add(cb.equal(usuario.get("departamento"), departamento));
        }

        if (activo != null) {
            predicates.add(cb.equal(usuario.get("activo"), activo));
        }

        if (!predicates.isEmpty()) {
            cq.where(cb.and(predicates.toArray(new Predicate[0])));
        }

        cq.orderBy(cb.asc(usuario.get("nombre")));

        TypedQuery<Usuario> query = entityManager.createQuery(cq);
        return query.getResultList();
    }

    @Override
    public Map<String, Long> obtenerEstadisticasPorDepartamento() {
        log.debug("Obteniendo estadísticas por departamento");

        String jpql = "SELECT u.departamento, COUNT(u) FROM Usuario u " +
                      "WHERE u.departamento IS NOT NULL " +
                      "GROUP BY u.departamento " +
                      "ORDER BY COUNT(u) DESC";

        List<Object[]> results = entityManager.createQuery(jpql, Object[].class)
                                             .getResultList();

        return results.stream()
                     .collect(Collectors.toMap(
                         row -> (String) row[0],
                         row -> (Long) row[1]
                     ));
    }

    @Override
    public List<Map<String, Object>> obtenerUsuariosMasActivos(int limit) {
        log.debug("Obteniendo top {} usuarios más activos", limit);

        String jpql = "SELECT u.idUsuario, u.nombre, u.email, COUNT(i.idInscripcion) as cursosCompletados " +
                      "FROM Usuario u " +
                      "LEFT JOIN Inscripcion i ON u.idUsuario = i.usuarioId " +
                      "WHERE i.estado = 'COMPLETADO' " +
                      "GROUP BY u.idUsuario, u.nombre, u.email " +
                      "ORDER BY COUNT(i.idInscripcion) DESC";

        List<Object[]> results = entityManager.createQuery(jpql, Object[].class)
                                             .setMaxResults(limit)
                                             .getResultList();

        List<Map<String, Object>> usuarios = new ArrayList<>();
        for (Object[] row : results) {
            Map<String, Object> usuario = new HashMap<>();
            usuario.put("idUsuario", row[0]);
            usuario.put("nombre", row[1]);
            usuario.put("email", row[2]);
            usuario.put("cursosCompletados", row[3]);
            usuarios.add(usuario);
        }

        return usuarios;
    }

    @Override
    public List<Usuario> obtenerUsuariosSinCursosCompletados() {
        log.debug("Obteniendo usuarios sin cursos completados");

        String jpql = "SELECT u FROM Usuario u " +
                      "WHERE u.rol = 'USER' " +
                      "AND u.activo = true " +
                      "AND NOT EXISTS (" +
                      "    SELECT i FROM Inscripcion i " +
                      "    WHERE i.usuarioId = u.idUsuario " +
                      "    AND i.estado = 'COMPLETADO'" +
                      ")";

        return entityManager.createQuery(jpql, Usuario.class).getResultList();
    }
}