package com.eam.capacitaciones.dao;

import com.eam.capacitaciones.domain.entity.Usuario;
import java.util.List;
import java.util.Map;

public interface CustomUsuarioDAO {
    
    List<Usuario> buscarUsuariosConFiltros(String nombre, String email, 
                                           String rol, String departamento, Boolean activo);

    Map<String, Long> obtenerEstadisticasPorDepartamento();

    List<Map<String, Object>> obtenerUsuariosMasActivos(int limit);

    List<Usuario> obtenerUsuariosSinCursosCompletados();
}